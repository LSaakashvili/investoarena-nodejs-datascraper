const express = require('express')
const app = express()
const Router = require('./router/router');
const path = require('path');

var NODENV = 'front';

app.use('/data/', Router);
app.use('/chart/', Router);
app.use('/data/', () => {
  NODENV = 'back';
})
app.use('/chart/', () => {
  NODENV = 'back';
})

if (NODENV === 'front') {
  app.use(express.static('frontend/build'));
  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'frontend', 'build', 'index.html'));
})
}


app.listen(process.env.PORT || 5500, (err) => {
    if (err) throw err;
    console.log("Server is running on 4000")
})