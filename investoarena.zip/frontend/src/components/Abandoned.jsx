import React, { useState, useEffect } from 'react';
import Sidebar from 'react-sidebar';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { Spinner } from 'react-bootstrap';

const Abandoned = () => {
    const [goldData, setGoldData] = useState({});
    const [gasolineData, setGasolineData] = useState({});
    const [platinumData, setPlatinumData] = useState({});
    const [fetchTime, setFetchTime] = useState(1);
    const [coalData, setCoalData] = useState({});
    const [coffeData, setCoffeData] = useState({});
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const onSetSidebarOpen = (open) => {
        setSidebarOpen(open)
    }
    const handleChange = (e) => {
        let inputfield = document.getElementById("search-input").value;
        if (inputfield.length > 2.5) {
            window.location.replace(`/search/${inputfield}`)
        }
    }
    const fetchData = async() => {
        const onSetSidebarOpen = (open) => {
            setSidebarOpen(open)
        }
        const handleChange = (e) => {
            let inputfield = document.getElementById("search-input").value;
            if (inputfield.length > 2.5) {
                window.location.replace(`/search/${inputfield}`)
            }
        }
        await axios.get('https://investoarena.herokuapp.com/data/gold')
        .then(res => {
            setGoldData(res.data)
        })
        .catch(err => {
            console.log(err)
        })
        await axios.get('https://investoarena.herokuapp.com/data/ethanol')
        .then(res => {
            setGasolineData(res.data)
        })
        .catch(err => {
            console.log(err)
        })
        await axios.get('https://investoarena.herokuapp.com/data/platinum')
        .then(res => {
            setPlatinumData(res.data)
        })
        .catch(err => {
            console.log(err)
        })
        await axios.get('https://investoarena.herokuapp.com/data/coal')
        .then(res => {
            setCoalData(res.data)
        })
        .catch(err => {
            console.log(err)
        })
        await axios.get('https://investoarena.herokuapp.com/data/coffee')
        .then(res => {
            setCoffeData(res.data)
        })
        .catch(err => {
            console.log(err)
        })
        setIsLoading(false);
    }
    useEffect(() => {
        fetchData();
    }, [fetchTime])
    return (
        <div className="main-cent">
        <div className="abandoned">
            <header className="header">
                <div className="header-up">
                    <Sidebar
                        sidebar={
                        <div id="sidebar">
                            <img src="/images/close-outline.svg" alt="" id="navbar-close" onClick={() => {
                                setSidebarOpen(false)
                            }}/>
                            <a href="/" id="a-sidebar">
                            <div className="container-sidebar-1">
                                <img src="/images/home-outline.svg" id="img-sidebar" alt=""/>
                                <p id="text-sidebar">Home</p>
                            </div>
                            </a>
                            <a href="/crypto/" id="a-sidebar">
                            <div className="container-sidebar">
                                <img src="/images/logo-bitcoin.svg" id="img-sidebar" alt=""/>
                                <p id="text-sidebar">Crypto</p>
                            </div>
                            </a>
                            <a href="/metals/" id="a-sidebar">
                            <div className="container-sidebar">
                                <img src="/images/metal.png" id="img-sidebar" alt=""/>
                                <p id="text-sidebar">Metals</p>
                            </div>
                            </a>
                            <a href="/gas/" id="a-sidebar">
                            <div className="container-sidebar">
                                <img src="/images/gas.png" id="img-sidebar" alt=""/>
                                <p id="text-sidebar">Gas</p>
                            </div>
                            </a>
                            <a href="/agriculture/" id="a-sidebar">
                            <div className="container-sidebar">
                                <img src="/images/agriculture.png" id="img-sidebar" alt=""/>
                                <p id="text-sidebar">Agriculture</p>
                            </div>
                            </a>
                        </div>
                    }
                        open={sidebarOpen}
                        onSetOpen={onSetSidebarOpen}
                        id="sidebar"
                        styles={{ sidebar: {background: "white", position:'fixed', left:'0px', width:'470px'}}}
                    >
      </Sidebar>
                    <Link to='/' id="title">I N V E S T O A R E N A</Link>
                    <div className="search">
                        <input autoComplete="off" type="text" id="search-input" placeholder="Tap to Search..."/>
                        <button onClick={handleChange} id='search-btn'><img src="/images/search-icon.png" id="search-img" alt=""/></button>
                   </div>
        <img id="navbar" src="/images/navbaricon.png" onClick={() => onSetSidebarOpen(true)}/>
                </div>
                <div className="header-down">
                    <div id="modal-header-box" className="modal1-header">
                    {isLoading === false &&
                    <div> 
                        <img id="primg" src={goldData.chp > 0 + '%' ? "images/progress.png":"images/regress.png" } alt=""/>
                        <p id="title-header-box">Gold</p>
                        <div className="pricechange">
                            <p className={goldData.chp > 0 + '%' ? "text-success mt-3":"text-danger mt-3"} id="modal-header-chp">{goldData.chp}</p>
                            <p className={goldData.ch > 0 ? "text-success mt-3":"text-danger mt-3"} id="modal-header-ch">{goldData.ch}</p>
                            <p id="modal-header-price">{goldData.price}$</p>
                        </div>
                    </div>
                     }
                     {isLoading && <Spinner animation="border"/>}
                    </div>
                    <div id="modal-header-box" className="modal2-header">
                        {isLoading === false &&
                        <div>
                        <img id="primg" src={coffeData.chp > 0 + '%' ? "images/progress.png":"images/regress.png" } alt=""/>
                        <p id="title-header-box">Coffee</p>
                        <div className="pricechange">
                        <p className={coffeData.chp > 0 + '%' ? "text-success mt-3":"text-danger mt-3"} id="modal-header-chp">{coffeData.chp}</p>
                        <p className={coffeData.ch > 0 ? "text-success mt-3":"text-danger mt-3"} id="modal-header-ch">{coffeData.ch}</p>
                        <p id="modal-header-price">{coffeData.price}$</p>
                        </div>
                        </div>
                        }
                        {isLoading && <Spinner animation="border"/>}
                        </div>
                    <div id="modal-header-box" className="modal3-header">
                        {isLoading === false && <div>
                        <img id="primg" src={coalData.chp > 0 + '%' ? "images/progress.png":"images/regress.png" } alt=""/>
                        <p id="title-header-box">Coal</p>
                        <div className="pricechange">
                        <p className={coalData.chp > 0 + '%' ? "text-success mt-3":"text-danger mt-3"} id="modal-header-chp">{coalData.chp}</p>
                        <p className={coalData.ch > 0 ? "text-success mt-3":"text-danger mt-3"} id="modal-header-ch">{coalData.ch}</p>
                        <p id="modal-header-price">{coalData.price}$</p></div></div>}
                     {isLoading && <Spinner animation="border"/>}</div>
                    <div id="modal-header-box" className="modal4-header">
                        {isLoading === false && <div>
                        <img id="primg" src={platinumData.chp > 0 + '%' ? "images/progress.png":"images/regress.png" } alt=""/>
                        <p id="title-header-box">Platinum</p>
                        <div className="pricechange">
                        <p className={platinumData.chp > 0 + '%' ? "text-success mt-3":"text-danger mt-3"} id="modal-header-chp">{platinumData.chp}</p>
                        <p className={platinumData.ch > 0 ? "text-success mt-3":"text-danger mt-3"} id="modal-header-ch">{platinumData.ch}</p>
                        <p id="modal-header-price">{platinumData.price}$</p></div></div>}
                     {isLoading && <Spinner animation="border"/>}</div>
                    <div id="modal-header-box" className="modal5-header">
                        {isLoading === false && <div>
                        <img id="primg" src={gasolineData.chp > 0 + '%' ? "images/progress.png":"images/regress.png" } alt=""/>
                        <p id="title-header-box">Ethanol</p>
                        <div className="pricechange">
                        <p className={gasolineData.chp > 0 + '%' ? "text-success mt-3":"text-danger mt-3"} id="modal-header-chp">{gasolineData.chp}</p>
                        <p className={gasolineData.ch > 0 ? "text-success mt-3":"text-danger mt-3"} id="modal-header-ch">{gasolineData.ch}</p>
                        <p id="modal-header-price">{gasolineData.price}$</p></div></div>}
                     {isLoading && <Spinner animation="border"/>}</div>
                </div>
            </header>
        <h1 id="abandoned-title">404</h1>
        </div>
        </div>
    )
}

export default Abandoned;