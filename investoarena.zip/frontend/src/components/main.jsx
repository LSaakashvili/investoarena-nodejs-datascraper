import React, {useState, useEffect} from 'react';
import { Spinner } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import Cryptolist from '../components/Cryptolist';
import axios from 'axios';
import Sidebar from 'react-sidebar';

const Main = () => {
    const [isLoading, setIsLoading] = useState(true);
    const [fetchTime, setFetchTime] = useState(1);
    const [goldData, setGoldData] = useState({});
    const [coalData, setCoalData] = useState({});
    const [coffeData, setCoffeData] = useState({});
    const [aluminum, setAluminum] = useState({});
    const [naturalgas, setNaturalgas] = useState({});
    const [gasoline, setGasoline] = useState({});
    const [palladiumData, setPalladiumData] = useState({});
    const [heatingoil, setHeatingoil] = useState({}); 
    const [platinumData, setPlatinumData] = useState({});
    const [cocoaData, setCocoaData] = useState({});
    const [soybeanoilData, setSoybeanoilData] = useState({});
    const [gasolineData, setGasolineData] = useState({});
    const [silverData, setSilverData] = useState({});
    const [metals, setMetals] = useState([]);
    const [agriculture, setAgriculture] = useState([]);
    const [gas, setGas] = useState([]);
    const [crypto, setCrypto] = useState([]);
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const fetchData = async() => {
        await axios.get('https://investoarena.herokuapp.com/data/gold')
        .then(res => {
            setGoldData(res.data)
        })
        .catch(err => {
            console.log(err)
        })
        await axios.get('https://investoarena.herokuapp.com/data/coal')
        .then(res => {
            setCoalData(res.data)
        })
        .catch(err => {
            console.log(err)
        })
        await axios.get('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false')
        .then(res => {
            setCrypto(res.data)
        })
        .catch(err => {
            console.log(err)
        });
        await axios.get('https://investoarena.herokuapp.com/data/coffee')
        .then(res => {
            setCoffeData(res.data)
        })
        .catch(err => {
            console.log(err)
        });
        await axios.get('https://investoarena.herokuapp.com/data/platinum')
        .then(res => {
            setPlatinumData(res.data)
        })
        .catch(err => {
            console.log(err)
        });
        await axios.get('https://investoarena.herokuapp.com/data/ethanol')
        .then(res => {
            setGasolineData(res.data)
        })
        .catch(err => {
            console.log(err)
        });
        await axios.get('https://investoarena.herokuapp.com/data/metals')
        .then(res => {
            setMetals(res.data);
        })
        await axios.get('https://investoarena.herokuapp.com/data/gas')
        .then(res => {
            setGas(res.data);
        })
        await axios.get('https://investoarena.herokuapp.com/data/agriculture')
        .then(res => {
            setAgriculture(res.data);
        })
        setIsLoading(false);
    }
    useEffect(() => {
        fetchData();
    }, [fetchTime])
    const onSetSidebarOpen = (open) => {
        setSidebarOpen(open)
    }
    const handleChange = (e) => {
        let inputfield = document.getElementById("search-input").value;
        if (inputfield.length > 2.5) {
            window.location.replace(`/search/${inputfield}`)
        }
    }
    return (
        <div className="main-cent">
        <div className="main">
            <header className="header">
                <div className="header-up">
                    <Sidebar
                        sidebar={
                        <div id="sidebar">
                            <img src="/images/close-outline.svg" alt="" id="navbar-close" onClick={() => {
                                setSidebarOpen(false)
                            }}/>
                            <a href="/" id="a-sidebar">
                            <div className="container-sidebar-1">
                                <img src="/images/home-outline.svg" id="img-sidebar" alt=""/>
                                <p id="text-sidebar">Home</p>
                            </div>
                            </a>
                            <a href="/crypto/" id="a-sidebar">
                            <div className="container-sidebar">
                                <img src="/images/logo-bitcoin.svg" id="img-sidebar" alt=""/>
                                <p id="text-sidebar">Crypto</p>
                            </div>
                            </a>
                            <a href="/metals/" id="a-sidebar">
                            <div className="container-sidebar">
                                <img src="/images/metal.png" id="img-sidebar" alt=""/>
                                <p id="text-sidebar">Metals</p>
                            </div>
                            </a>
                            <a href="/gas/" id="a-sidebar">
                            <div className="container-sidebar">
                                <img src="/images/gas.png" id="img-sidebar" alt=""/>
                                <p id="text-sidebar">Gas</p>
                            </div>
                            </a>
                            <a href="/agriculture/" id="a-sidebar">
                            <div className="container-sidebar">
                                <img src="/images/agriculture.png" id="img-sidebar" alt=""/>
                                <p id="text-sidebar">Agriculture</p>
                            </div>
                            </a>
                        </div>
                    }
                        open={sidebarOpen}
                        onSetOpen={onSetSidebarOpen}
                        id="sidebar"
                        styles={{ sidebar: {background: "white", position:'fixed', left:'0px', width:'470px'}}}
                    >
      </Sidebar>
                    <Link to='/' id="title">I N V E S T O A R E N A</Link>
                    <div className="search">
                        <input autoComplete="off" type="text" id="search-input" placeholder="Tap to Search..."/>
                        <button onClick={handleChange} id='search-btn'><img src="/images/search-icon.png" id="search-img" alt=""/></button>
                   </div>
        <img alt="" id="navbar" src="/images/navbaricon.png" onClick={() => onSetSidebarOpen(true)}/>
                </div>
                <div className="header-down">
                    <div id="modal-header-box" className="modal1-header">
                    {isLoading === false &&
                    <div> 
                        <img id="primg" src={goldData.chp > 0 + '%' ? "images/progress.png":"images/regress.png" } alt=""/>
                        <p id="title-header-box">Gold</p>
                        <div className="pricechange">
                            <p className={goldData.chp > 0 + '%' ? "text-success mt-3":"text-danger mt-3"} id="modal-header-chp">{goldData.chp}</p>
                            <p className={goldData.ch > 0 ? "text-success mt-3":"text-danger mt-3"} id="modal-header-ch">{goldData.ch}</p>
                            <p id="modal-header-price">{goldData.price}$</p>
                        </div>
                    </div>
                     }
                     {isLoading && <Spinner animation="border"/>}
                    </div>
                    <div id="modal-header-box" className="modal2-header">
                        {isLoading === false &&
                        <div>
                        <img id="primg" src={coffeData.chp > 0 + '%' ? "images/progress.png":"images/regress.png" } alt=""/>
                        <p id="title-header-box">Coffee</p>
                        <div className="pricechange">
                        <p className={coffeData.chp > 0 + '%' ? "text-success mt-3":"text-danger mt-3"} id="modal-header-chp">{coffeData.chp}</p>
                        <p className={coffeData.ch > 0 ? "text-success mt-3":"text-danger mt-3"} id="modal-header-ch">{coffeData.ch}</p>
                        <p id="modal-header-price">{coffeData.price}$</p>
                        </div>
                        </div>
                        }
                        {isLoading && <Spinner animation="border"/>}
                        </div>
                    <div id="modal-header-box" className="modal3-header">
                        {isLoading === false && <div>
                        <img id="primg" src={coalData.chp > 0 + '%' ? "images/progress.png":"images/regress.png" } alt=""/>
                        <p id="title-header-box">Coal</p>
                        <div className="pricechange">
                        <p className={coalData.chp > 0 + '%' ? "text-success mt-3":"text-danger mt-3"} id="modal-header-chp">{coalData.chp}</p>
                        <p className={coalData.ch > 0 ? "text-success mt-3":"text-danger mt-3"} id="modal-header-ch">{coalData.ch}</p>
                        <p id="modal-header-price">{coalData.price}$</p></div></div>}
                     {isLoading && <Spinner animation="border"/>}</div>
                    <div id="modal-header-box" className="modal4-header">
                        {isLoading === false && <div>
                        <img id="primg" src={platinumData.chp > 0 + '%' ? "images/progress.png":"images/regress.png" } alt=""/>
                        <p id="title-header-box">Platinum</p>
                        <div className="pricechange">
                        <p className={platinumData.chp > 0 + '%' ? "text-success mt-3":"text-danger mt-3"} id="modal-header-chp">{platinumData.chp}</p>
                        <p className={platinumData.ch > 0 ? "text-success mt-3":"text-danger mt-3"} id="modal-header-ch">{platinumData.ch}</p>
                        <p id="modal-header-price">{platinumData.price}$</p></div></div>}
                     {isLoading && <Spinner animation="border"/>}</div>
                    <div id="modal-header-box" className="modal5-header">
                        {isLoading === false && <div>
                        <img id="primg" src={gasolineData.chp > 0 + '%' ? "images/progress.png":"images/regress.png" } alt=""/>
                        <p id="title-header-box">Ethanol</p>
                        <div className="pricechange">
                        <p className={gasolineData.chp > 0 + '%' ? "text-success mt-3":"text-danger mt-3"} id="modal-header-chp">{gasolineData.chp}</p>
                        <p className={gasolineData.ch > 0 ? "text-success mt-3":"text-danger mt-3"} id="modal-header-ch">{gasolineData.ch}</p>
                        <p id="modal-header-price">{gasolineData.price}$</p></div></div>}
                     {isLoading && <Spinner animation="border"/>}</div>
                </div>
            </header>
            <div className="center-box">
                <p id="center-box-title1">Commodities Top Performers</p>
                <div id="line"></div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false && 
                        <div><Link to='/agriculture/coffee' id="commodities-title">Coffee</Link>
                        <p id="commodities-price">{agriculture[3].price} USD</p>
                        <p id="commodities-chp" className={agriculture[3].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{agriculture[3].chp}</p></div>}
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& 
                        <div><Link to='/agriculture/cocoa' id="commodities-title">Cocoa</Link>
                        <p id="commodities-price">{agriculture[4].price} USD</p>
                        <p id="commodities-chp" className={agriculture[4].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{agriculture[4].chp}</p></div>}
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/gas/heatingoil' id="commodities-title">Heating Oil</Link>
                        <p id="commodities-price">{gas[2].price} USD</p>
                        <p id="commodities-chp" className={agriculture[2].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{agriculture[2].chp}</p></div>}
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/agriculture/soybeanoil' id="commodities-title">Soybean Oil</Link>
                        <p id="commodities-price">{agriculture[14].price} USD</p>
                        <p id="commodities-chp" className={agriculture[14].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{agriculture[14].chp}</p></div>}
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/metals/silver' id="commodities-title">Silver</Link>
                        <p id="commodities-price">{metals[4].price} USD</p>
                        <p id="commodities-chp" className={metals[4].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{metals[4].chp}</p></div>}
                    </div>
                </div>
                <p id="center-box-title1">Commodity Prices</p>
                <div id="line"></div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        <p id="commodities-title">Metals</p>
                        <p id="commodities-price">Price</p>
                        <p id="commodities-chp-c">%</p>
                        <p id="commodities-chp-c-c">+/-</p>
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/metals/gold' id="commodities-title">Gold</Link>
                        <p id="commodities-price">{metals[0].price} USD</p>
                        <p id="commodities-ch-2" className={metals[0].ch > 0 ? "text-success mr-2" : "text-danger mr-2"}>{metals[0].ch}$</p>
                        <p id="commodities-chp-2" className={metals[0].ch > 0  ? "text-success mr-2":"text-danger mr-2"}>{metals[0].chp}</p></div>
                        }
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/metals/silver' id="commodities-title">Silver</Link>
                        <p id="commodities-price">{metals[4].price} USD</p>
                        <p id="commodities-ch-2" className={metals[4].ch > 0 ? "text-success mr-2" : "text-danger mr-2"}>{metals[4].ch}$</p>
                        <p id="commodities-chp-2" className={metals[4].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{metals[4].chp}</p></div>
                        }
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/metals/platinum' id="commodities-title">Platinum</Link>
                        <p id="commodities-price">{metals[2].price} USD</p>
                        <p id="commodities-ch-2" className={metals[2].ch > 0 ? "text-success mr-2" : "text-danger mr-2"}>{metals[2].ch}$</p>
                        <p id="commodities-chp-2" className={metals[2].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{metals[2].chp}</p></div>
                        }
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/metals/palladium' id="commodities-title">Palladium</Link>
                        <p id="commodities-price">{metals[1].price} USD</p>
                        <p id="commodities-ch-2" className={metals[1].ch > 0 ? "text-success mr-2" : "text-danger mr-2"}>{metals[1].ch}$</p>
                        <p id="commodities-chp-2" className={metals[1].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{metals[1].chp}</p></div>
                        }
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/metals/aluminum' id="commodities-title">Aluminium</Link>
                        <p id="commodities-price">{metals[5].price} USD</p>
                        <p id="commodities-ch-2" className={metals[5].ch > 0 ? "text-success mr-2" : "text-danger mr-2"}>{metals[5].ch}$</p>
                        <p id="commodities-chp-2" className={metals[5].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{metals[5].chp}</p></div>
                        }
                    </div>
                </div>
                <div className="commodities-container2">
                    <div className="commodities-row">
                        <p id="commodities-title">Energy</p>
                        <p id="commodities-price">Price</p>
                        <p id="commodities-chp-c">%</p>
                        <p id="commodities-chp-c-c">+/-</p>
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/gas/naturalgas' id="commodities-title">Natural Gas</Link>
                        <p id="commodities-price">{gas[0].price} USD</p>
                        <p id="commodities-ch-2" className={gas[0].ch > 0 ? "text-success mr-2" : "text-danger mr-2"}>{gas[0].ch}$</p>
                        <p id="commodities-chp-2" className={gas[0].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{gas[0].chp}</p></div>
                        }
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/gas/ethanol' id="commodities-title">Ethanol</Link>
                        <p id="commodities-price">{gas[1].price} USD</p>
                        <p id="commodities-ch-2" className={gas[1].ch > 0 ? "text-success mr-2" : "text-danger mr-2"}>{gas[1].ch}$</p>
                        <p id="commodities-chp-2" className={gas[1].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{gas[1].chp}</p></div>
                        }
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/commodities/heatingoil' id="commodities-title">Heating Oil</Link>
                        <p id="commodities-price">{gas[2].price} USD</p>
                        <p id="commodities-ch-2" className={gas[2].ch > 0 ? "text-success mr-2" : "text-danger mr-2"}>{gas[2].ch}$</p>
                        <p id="commodities-chp-2" className={gas[2].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{gas[2].chp}</p></div>
                        }
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/commodities/coal' id="commodities-title">Coal</Link>
                        <p id="commodities-price">{gas[3].price} USD</p>
                        <p id="commodities-ch-2" className={gas[3].ch > 0 ? "text-success mr-2" : "text-danger mr-2"}>{gas[3].ch}$</p>
                        <p id="commodities-chp-2" className={gas[3].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{gas[3].chp}</p></div>
                        }
                    </div>
                </div>
                <div className="commodities-container">
                    <div className="commodities-row">
                        {isLoading === false&& <div><Link to='/commodities/gasoline' id="commodities-title">RBOB Gasoline</Link>
                        <p id="commodities-price">{gas[4].price} USD</p>
                        <p id="commodities-ch-2" className={gas[4].ch > 0 ? "text-success mr-2" : "text-danger mr-2"}>{gas[4].ch}$</p>
                        <p id="commodities-chp-2" className={gas[4].chp > 0 + '%' ? "text-success mr-2":"text-danger mr-2"}>{gas[4].chp}</p></div>
                        }
                    </div>
                </div>
                <p id="center-box-title1">Top Cryptocurrencies</p>
                <div id="line"></div>
    
                {crypto.map(coin => {
                    return (
                    <Cryptolist name={coin.name} id={coin.id} price={coin.current_price} ch={coin.price_change_24h} chp={coin.price_change_percentage_24h} />
                    )
                })}
                {isLoading &&<div id="modal-bg"><Spinner animation="border" variant="primary" id="spinner-modal"/></div>}
                </div>
                </div>
            </div>
    )
}

export default Main;